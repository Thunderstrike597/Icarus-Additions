package net.kenji.icarus_additions.updraft;

import dev.cammiescorner.icarus.item.WingItem;
import dev.cammiescorner.icarus.util.IcarusHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

public final class UpdraftHelper {
    private UpdraftHelper() {}

    /** Updraft level on the equipped Icarus wings (Curios or chest, whatever Icarus uses), 0 if none/unusable. */
    public static int getLevel(Player player) {
        if (!IcarusHelper.hasWings(player)) return 0;
        ItemStack wings = IcarusHelper.getEquippedWings(player);
        if (wings.isEmpty() || !(wings.getItem() instanceof WingItem wingItem) || !wingItem.isUsable(player, wings)) {
            return 0;
        }
        return EnchantmentHelper.getItemEnchantmentLevel(IcarusAdditionsEnchantments.UPDRAFT.get(), wings);
    }

    /** Blocks lifted for this level: base height x multiplier^(level - 1). */
    public static double getLiftHeight(int level) {
        if (level <= 0) return 0.0D;
        return UpdraftConfig.BASE_LIFT_HEIGHT.get() * Math.pow(UpdraftConfig.LEVEL_MULTIPLIER.get(), level - 1);
    }

    /** Situations where charging/launching makes no sense. */
    public static boolean canUse(Player player) {
        return !player.isPassenger()
                && !player.isSpectator()
                && !player.getAbilities().flying
                && !player.isInWater()
                && !player.isInLava()
                && !player.isFallFlying();
    }
}
